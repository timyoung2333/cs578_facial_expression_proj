All the required files are listed in the zip file, including

* report.pdf - preliminary project report
* FER2013.py - data preprocessing
* Perceptron.py - implementation of multi-class perceptron algorithm
* AdaBoost.py - implementation of AdaBoost algorithm
* SVM.py - implementation of Support Vector Machine
* Evaluation.py - Our own implementation of k-fold cross validation and bootstrapping
* Visualize.py - Code for generating figures

